import { Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef, OnChanges } from '@angular/core';
import { DatePipe } from '@angular/common';

import { MaInputComponent, MakeProvider } from './ma-input.component';
import { ControlValueAccessor } from './control-value-accessor';

@Component({
  selector: 'ma-date-picker',
  template: `
  <div class="datepicker">
    <date-picker [hidden]="!datePickerOpen" [startDate]="minDate" [endDate]="maxDate" [ngModel]="value" (maDateOnChange)="updateValue($event);closeDatePicker()"
        ></date-picker>
    <input type="hidden" name="{{name}}" id="{{id}}" class="field hasDatepicker" [(ngModel)]="value" [required]="required" />
    <input autocomplete="off" type="text" name="display_{{name}}" id="display_{{id}}" class="field hasDatepicker" [(ngModel)]="displayDate" (ngModelChange)="updateValue(null)"
        (blur)="convertToDate(false)" (click)="openDatePicker()" [placeholder]="placeholder" [disabled]="disabled" [readonly]="readOnly" [required]="required">
    <button type="button" class="ui-datepicker-trigger" (click)="openDatePicker()" [disabled]="disabled">...</button>
</div>
  `,
  providers: [MakeProvider(MaDatePickerComponent)]
})
export class MaDatePickerComponent extends MaInputComponent implements OnInit, OnChanges, ControlValueAccessor {
  @Input() ngModel: any;
  @Input() name: string;
  @Input() id: any;
  @Input() readOnly: boolean;
  @Input() disabled: boolean;
  @Input() required: boolean;
  @Input() minDate: any;
  @Input() maxDate: any;
  @Input() placeholder: string;
  @Input() displayDateFormat: string;
  @Output() maDateOnChange = new EventEmitter<Date>();
  @Output() ngModelChange = new EventEmitter<Date>();
  @Output() blur = new EventEmitter<any>();
  displayDate: string;
  datePickerOpen: boolean;
  pickerDate: Date;
  @HostListener('document:click', ['$event'])
  clickout(event: any) {
    if (!this.eRef.nativeElement.contains(event.target)) {
      this.closeDatePicker();
    }
  }

  constructor(private eRef: ElementRef) {
    super();
    this.initialize();
  }

  ngOnInit() {
  }

  ngOnChanges(): void {
    this.minDate = this.minDate ? (this.isValidDate(this.minDate) ? this.minDate : new Date(Date.parse(this.minDate))) : null;
    this.maxDate = this.maxDate ? (this.isValidDate(this.maxDate) ? this.maxDate : new Date(Date.parse(this.maxDate))) : null;
    this.ngModel = this.ngModel ? (this.isValidDate(this.ngModel) ? this.ngModel : new Date(Date.parse(this.ngModel))) : null;
    this.initDate();
  }

  initDate(): void {
    this.value = this.ngModel = (this.ngModel ? new Date(this.ngModel) : null);
    if (this.ngModel && Object.prototype.toString.call(this.ngModel) === '[object Date]') {
      this.displayDate = new DatePipe('en-US').transform(this.ngModel, this.displayDateFormat ? this.displayDateFormat : 'MM/dd/yyyy');
    } else {
      this.displayDate = null;
    }
  }

  isValidDate(date: any) {
    return date && Object.prototype.toString.call(date) === '[object Date]' && !isNaN(date);
  }

  updateValue(date: Date): void {
    if (date && !this.readOnly && !this.disabled) {
      this.ngModel = date;
      this.convertToDate(true);
    }
    this.value = this.ngModel;
    this.ngModelChange.emit(this.ngModel);
    this.maDateOnChange.emit(this.ngModel);
  }

  convertToDate(ignoreDisplayDate: boolean): void {
    this.onTouched();
    this.blur.emit();
    if (!ignoreDisplayDate) {
      this.value = this.ngModel = new Date(Date.parse(this.displayDate));
    }
    if (Object.prototype.toString.call(this.ngModel) === '[object Date]') {
      if (isNaN(this.ngModel.getTime())) {
       this.value = this.ngModel = null;
        this.displayDate = '';
      } else {
        this.displayDate = new DatePipe('en-US').transform(new Date(this.ngModel), this.displayDateFormat ? this.displayDateFormat : 'MM/dd/yyyy');
      }
    }
  }

  openDatePicker(): void {
    this.onTouched();
    this.datePickerOpen = !this.datePickerOpen;
  }

  closeDatePicker(): void {
    this.datePickerOpen = false;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  onTouched() { }

  private initialize(): void {
    this.displayDate = '';
    this.datePickerOpen = false;
    this.pickerDate = null;
  }
}
